/**
 * server/proxy.js — ZERØ MERIDIAN API Proxy
 * All paid API keys live SERVER-SIDE only — never shipped to client bundle.
 * Run: node server/proxy.js  (or via pm2/docker)
 * 
 * Routes:
 *   GET /api/santiment/social-volume
 *   GET /api/santiment/twitter-volume
 *   GET /api/token-terminal/projects
 *   GET /api/messari/btc
 *   GET /api/messari/eth
 *   GET /api/messari/sol
 *   GET /api/messari/news
 *   GET /api/dune/:queryId
 */

const http = require('http');
const https = require('https');
const url = require('url');

// ── API Keys (set via environment variables — NEVER hardcode) ─────────────────
const KEYS = {
  santiment:     process.env.ZM_SANTIMENT_KEY     || '',
  tokenTerminal: process.env.ZM_TOKEN_TERMINAL_KEY || '',
  messari:       process.env.ZM_MESSARI_KEY        || '',
  dune:          process.env.ZM_DUNE_KEY           || '',
  theGraph:      process.env.ZM_GRAPH_KEY          || '',
};

const PORT = process.env.ZM_PROXY_PORT || 3001;

// ── In-memory cache (TTL per route) ──────────────────────────────────────────
const cache = new Map();

function getCached(key, ttlMs) {
  const entry = cache.get(key);
  if (entry && Date.now() - entry.ts < ttlMs) return entry.data;
  return null;
}

function setCached(key, data) {
  cache.set(key, { data, ts: Date.now() });
}

// ── Proxy fetch helper ────────────────────────────────────────────────────────
function proxyFetch(targetUrl, headers = {}) {
  return new Promise((resolve, reject) => {
    const parsed = url.parse(targetUrl);
    const lib = parsed.protocol === 'https:' ? https : http;
    const req = lib.get({ ...parsed, headers }, (res) => {
      let body = '';
      res.on('data', d => body += d);
      res.on('end', () => {
        try { resolve(JSON.parse(body)); }
        catch { reject(new Error('Invalid JSON from upstream')); }
      });
    });
    req.on('error', reject);
    req.setTimeout(8000, () => { req.destroy(); reject(new Error('Upstream timeout')); });
  });
}

// ── CORS headers ──────────────────────────────────────────────────────────────
function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', process.env.ZM_ALLOWED_ORIGIN || 'http://localhost:8080');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
}

function json(res, data, status = 200) {
  res.writeHead(status, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(data));
}

// ── Router ────────────────────────────────────────────────────────────────────
const ROUTES = {
  '/api/santiment/social-volume': async () => {
    const cached = getCached('sv', 60_000);
    if (cached) return cached;
    const data = await proxyFetch('https://api.santiment.net/graphql', {
      'Authorization': `Apikey ${KEYS.santiment}`,
      'Content-Type': 'application/json',
    });
    setCached('sv', data);
    return data;
  },

  '/api/token-terminal/projects': async () => {
    const cached = getCached('tt', 120_000);
    if (cached) return cached;
    const data = await proxyFetch(
      'https://api.tokenterminal.com/v2/projects',
      { 'Authorization': `Bearer ${KEYS.tokenTerminal}` }
    );
    setCached('tt', data);
    return data;
  },

  '/api/messari/btc': async () => {
    const cached = getCached('mbTC', 30_000);
    if (cached) return cached;
    const data = await proxyFetch(
      'https://data.messari.io/api/v1/assets/bitcoin/metrics',
      { 'x-messari-api-key': KEYS.messari }
    );
    setCached('mbTC', data);
    return data;
  },

  '/api/messari/eth': async () => {
    const cached = getCached('mETH', 30_000);
    if (cached) return cached;
    const data = await proxyFetch(
      'https://data.messari.io/api/v1/assets/ethereum/metrics',
      { 'x-messari-api-key': KEYS.messari }
    );
    setCached('mETH', data);
    return data;
  },

  '/api/messari/sol': async () => {
    const cached = getCached('mSOL', 30_000);
    if (cached) return cached;
    const data = await proxyFetch(
      'https://data.messari.io/api/v1/assets/solana/metrics',
      { 'x-messari-api-key': KEYS.messari }
    );
    setCached('mSOL', data);
    return data;
  },

  '/api/messari/news': async () => {
    const cached = getCached('mnews', 300_000);
    if (cached) return cached;
    const data = await proxyFetch(
      'https://data.messari.io/api/v1/news',
      { 'x-messari-api-key': KEYS.messari }
    );
    setCached('mnews', data);
    return data;
  },
};

// ── Server ────────────────────────────────────────────────────────────────────
const server = http.createServer(async (req, res) => {
  cors(res);
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }
  if (req.method !== 'GET')     { json(res, { error: 'Method not allowed' }, 405); return; }

  const pathname = url.parse(req.url).pathname;

  // Dune dynamic route
  if (pathname.startsWith('/api/dune/')) {
    const queryId = pathname.split('/')[3];
    if (!queryId) { json(res, { error: 'Missing query ID' }, 400); return; }
    const cKey = `dune_${queryId}`;
    const cached = getCached(cKey, 300_000); // 5 min
    if (cached) { json(res, cached); return; }
    try {
      const data = await proxyFetch(
        `https://api.dune.com/api/v1/query/${queryId}/results`,
        { 'X-Dune-API-Key': KEYS.dune }
      );
      setCached(cKey, data);
      json(res, data);
    } catch (e) {
      json(res, { error: e.message }, 502);
    }
    return;
  }

  const handler = ROUTES[pathname];
  if (!handler) { json(res, { error: 'Not found' }, 404); return; }

  try {
    const data = await handler();
    json(res, data);
  } catch (e) {
    console.error('[proxy]', pathname, e.message);
    json(res, { error: 'Upstream error', detail: e.message }, 502);
  }
});

server.listen(PORT, () => {
  console.log(`[ZM Proxy] Running on port ${PORT}`);
  console.log('[ZM Proxy] Keys configured:', Object.entries(KEYS).filter(([,v]) => v).map(([k]) => k).join(', ') || 'NONE - set env vars!');
});
