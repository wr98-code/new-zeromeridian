# ZERØ MERIDIAN — Production Fixes

Applied by technical audit — Feb 28, 2026.

## Critical Fixes Applied

### FIX-001: Closure Bug in CryptoContext (stale state race condition)
**File:** `src/contexts/CryptoContext.tsx`
- Added `stateRef` pattern: `const stateRef = useRef(state)` + `useEffect(() => { stateRef.current = state }, [state])`
- `enhancedDispatch` now uses `stateRef.current.assets` instead of stale `state.assets` from closure
- Changed `useCallback([state])` → `useCallback([])` — dispatch is now a stable reference
- **Impact:** Eliminates unnecessary re-renders on all CryptoContext consumers, fixes stale price merge race condition

### FIX-002: Live basePrice for WasmOrderBook (was hardcoded)
**File:** `src/pages/Dashboard.tsx`
- WasmOrderBook now reads `btcPrice` and `ethPrice` live from CryptoContext
- Was: `basePrice={67840}` → Now: `basePrice={btcPrice}` (always current)

### FIX-003: Real WASM Binary Built and Deployed
**File:** `public/wasm/orderbook.wasm`
- Compiled actual WebAssembly binary (395 bytes) implementing full orderbook computation
- Implements: totalBidQty, totalAskQty, bidVWAP, askVWAP, midPrice, spread, orderImbalance
- Validated with WebAssembly.validate() — ✓ PASSES
- Tested with real bid/ask data — correct results verified

### FIX-004: ErrorBoundary for All Dashboard Tiles
**File:** `src/components/shared/ErrorBoundary.tsx` (NEW)
- New React Error Boundary class component with retry button
- Applied to all 9 tiles in Dashboard — no more full-page crash on tile error
- Shows isolated error card with tile label and error message

### FIX-005: Stale Data Indicator
**File:** `src/pages/Dashboard.tsx`
- Added prominent banner when wsStatus !== 'connected'
- Shows "RECONNECTING — DATA MAY BE STALE" (yellow) or "DISCONNECTED" (red)
- Accessible: role="alert" aria-live="assertive"

### FIX-006: WCAG AA Contrast Fix
**File:** `src/index.css`
- `--zm-text-faint` changed from `rgba(80,80,100,1)` to `rgba(130,130,155,1)`
- New contrast ratio vs dark background: ~5.2:1 (was ~2.8:1, required ≥4.5:1)

### FIX-007: API Security — Backend Proxy Server
**File:** `server/proxy.js` (NEW)
- All paid API keys (Santiment, Token Terminal, Messari, Dune) moved server-side
- Frontend hooks now call `/api/*` routes — zero credentials in browser bundle
- Built-in in-memory cache per endpoint (TTL: 30s-5min depending on data type)
- CORS protection: only allows configured origin
- Hooks updated: `useSantiment`, `useTokenTerminal`, `useMessari`, `useDuneAnalytics`

### FIX-008: CoinGecko Rate-Limit Guard
**File:** `src/lib/cgCache.ts` (NEW)
- Centralized CoinGecko fetch with 2.2s minimum interval between requests
- In-flight request deduplication (multiple hooks calling same endpoint → 1 request)
- TTL-based cache: returns fresh data without hitting rate limits

### FIX-009: Content Security Policy
**File:** `index.html`
- Added CSP meta tag allowing only: self, TradingView scripts, Google Fonts, Binance WSS
- Prevents XSS script injection from third-party sources

### FIX-010: Three.js Bundle Isolation
**File:** `vite.config.ts`
- Removed `vendor-three` from `manualChunks` — Three.js no longer eagerly bundled
- Load Three.js only in components that actually use it via dynamic import

### FIX-011: Real Unit Tests
**File:** `src/test/formatters.test.ts` (NEW)
- Tests for `formatPrice`, `formatCompact`, `detectRegime`, `computeSignal`
- Covers edge cases: empty arrays, NaN, regime boundaries
- Run: `npm test`

## Deployment Checklist

Before going live:
1. `cp .env.example .env` and fill in API keys
2. `node server/proxy.js` (or deploy to cloud function/server)
3. Update `ZM_ALLOWED_ORIGIN` in proxy to your production domain
4. Set `ZM_PROXY_PORT` appropriately
5. Update CSP in `index.html` to match your production proxy domain
6. `npm run build` for optimized bundle
7. Confirm WASM file is in `dist/wasm/orderbook.wasm` after build

## Remaining Recommendations (Phase 3)

- Add OKX/Bybit WebSocket for multi-exchange order book aggregation
- Implement WalletConnect v2 for portfolio auto-sync
- Server-side alert notifications (Telegram/email) — browser push not reliable
- CSV export for historical data
- Rename "AI Signal" → "Quantitative Signal" for regulatory accuracy
